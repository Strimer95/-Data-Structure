#include <iostream>
#include <cstring>

struct Node{
    int data;
    Node* next;
}*head = NULL;

void insert(struct Node *p)
{
    struct Node *
}
void createString()
{

}
int main()
{
    int A[] = {1,2,1,1,2,1};

}